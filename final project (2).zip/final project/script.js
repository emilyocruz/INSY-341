
//issues with firebase --> try to put import { initializeApp } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js";
//but whenever added it messes up my game over page with player score 
const firebaseConfig = {
  apiKey: "AIzaSyDvAKeooTRc7dHtsknsnovEcCmGyfDEk_k",
  authDomain: "final-project-a424c.firebaseapp.com",
  projectId: "final-project-a424c",
  storageBucket: "final-project-a424c.appspot.com",
  messagingSenderId: "617885180292",
  appId: "1:617885180292:web:5ddcd257338bcdf8427dd1",
  measurementId: "G-ZRW1NEN2Z1"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

  //declare variables 
  var playerCards;
  var cardsData;
  var middleCard;
  var deckId;
  var selectedPlayerCard;
  var selectedComputerCard;
  var playerPoints;
  var computerPoints;

  //function for when the player types their name in the index.html
  function search() {
    // get the input value inputed by user from the first page
    const playerNameInput = document.getElementById('playerName');
    const playerName = playerNameInput.value;
  
    /* save the player's name to localStorage for use on the second page, 
    https://developer.mozilla.org/en-US/docs/Web/API/Window/localStorage, 
    https://blog.logrocket.com/localstorage-javascript-complete-guide/*/
    localStorage.setItem('playerName', playerName);
  
    // navigate to the second page once the start game button is clicked 
    //searched online "how to redirect to new page javascript": window.location.href
    window.location.href = 'game-page.html';
  }
  //function for next round
  function nextRound() {
    //fetch 2 cards from the API
    fetch(`https://deckofcardsapi.com/api/deck/${deckId}/draw/?count=2`)
    .then(response => {
      return response.json();
    })
    .then(function (cardsData) {
      //retrieve next round button from game-page.html
      var nextCardColorDisplay = document.getElementById('nextRoundButton');
      //hide next round button for first round since it does not need to be shown until player actually plays a round first, https://www.tutorialspoint.com/How-to-hide-HTML-element-with-JavaScript
      nextCardColorDisplay.hidden = true; 

      //remove previously selected card by player 
      removeCard(playerCards, selectedPlayerCard);
      //push (add) new card to players cards 
      playerCards.push(cardsData.cards[0]);

      //remove previously selected card by computer
      removeCard(computerCards, selectedComputerCard);
      //push new card to computer's cards
      computerCards.push(cardsData.cards[1]);

      //display updated hands for computer, player and as well as the middle card which needs to be changed 
      displayPlayerCards();
      //to keep computer cards face down --> not defined object, when parameter of function is (null) makes all cards face down 
      //https://www.programiz.com/javascript/null-undefined
      displayComputerCards(null);
      getMiddleCard();

      //retrieve middle card display from game-page.html
      var middleCardDisplay = document.getElementById('middleCard');
      //face down image for the middle card
      middleCardDisplay.src = 'back-card.png'; 
      }
    );
  }
  //function to remove the selected card
  function removeCard(array, value) {
    // Find the index of the card in the array, https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/indexOf
    var index = array.indexOf(value);
    //check if card is in array, -1 because the first element of an array is of 0
    if (index > -1) {
      //use splice to remove card from the array, https://stackoverflow.com/questions/5767325/how-can-i-remove-a-specific-item-from-an-array-in-javascript
      array.splice(index, 1);
    }
    //return updated array 
    return array;
  }

//function to shuffle cards
  function shuffleCards() {
    //shuffle the deck API
    fetch(`https://deckofcardsapi.com/api/deck/new/shuffle/?deck_count=1`)
    .then(response => {
      return response.json();
    })
    .then(data => {
      //retrive deck ID from API response 
      deckId = data.deck_id;
      //make both player and computer start the game at 0 points 
      playerPoints = 0; 
      computerPoints = 0; 
      //display player name 
      getPlayerName();

      //initial points dispplay for the computer (start at 0)
      computerPoints = 0;
      var computerPointsDisplay = document.getElementById('computerPoints');
      //text content - to return text --> https://developer.mozilla.org/en-US/docs/Web/API/Node/textContent, https://www.w3schools.com/jsref/prop_node_textcontent.asp
      computerPointsDisplay.textContent = computerPoints + ""; 
      //initial points display for the player (start at 0)
      playerPoints = 0;
      var playerPointsDisplay = document.getElementById('playerPoints');
      //same source as previously used 
      playerPointsDisplay.textContent = playerPoints + ""; 
    
      getCardsForPlayers();
    });
  }

//function to get player's name from local storage
  function getPlayerName() {
     //retrieve player name from index page (browser's local storage) and assign it to the variable
    const playerName = localStorage.getItem('playerName');
    // selects the HTML element and assigns it to the variable
    const playerNameDisplay = document.getElementById('playerNameDisplay'); 
    //sets the text content of the selected element to the value of playerName - displays the players name entered in index html 
    playerNameDisplay.textContent = playerName; 
  }

  //drawing the 10 cards from the deck (5 player, 5 computer)
  function getCardsForPlayers() {
    fetch(`https://deckofcardsapi.com/api/deck/${deckId}/draw/?count=10`)
    .then(response => {
      return response.json();
    })
    .then(function (cardsData) {
      /*display player and computer cards, seperated using slice --> 
      https://medium.com/@drdDavi/split-a-javascript-array-into-chunks-d90c90de3a2d#:~:text=To%20split%20a%20JavaScript%20array%20into%20chunks%2C%20we%20can%20use,the%20array%20to%20be%20returned.
      https://www.freecodecamp.org/news/javascript-slice-and-splice-how-to-use-the-slice-and-splice-js-array-methods/*/
      playerCards = cardsData.cards.slice(0,5);
      displayPlayerCards();         
      computerCards = cardsData.cards.slice(5, 10);
      displayComputerCards(null);

      getMiddleCard();
      }
    );
  }
  //function to get middle card for the game
  function getMiddleCard() {
    fetch(`https://deckofcardsapi.com/api/deck/${deckId}/draw/?count=1`)
    .then(response => {
      return response.json();
    })
    .then(function (cardsData) {   
      //should be 13 rounds, this function checks if a card can be drawn from the deck 
      if (cardsData.cards.length != 1) {
        //if not game is over, thus gameOverPage function called
        gameOverPage(); 
        return;
      }    
      //retrieve the drawn card and assign it to middleCard variable
      middleCard = cardsData.cards[0];
      //update the display to indicate the color of the next card color 
      var nextCardColorDisplay = document.getElementById('nextCardColorDisplay');
      //source for textContent provided
      nextCardColorDisplay.textContent = `The next card is ${getColor(middleCard.suit)}`; 
    })
  }

  //display player cards 
  function displayPlayerCards() {
    //get the container element where player cards will be displayed
    const playerCardsContainer = document.getElementById('playerCards');
    //call the displayCards function to display the player's cards in the specified container
    displayCards(playerCards, playerCardsContainer);
  }

  //display computer cards face down 
  function displayComputerCards(cardIndex) {
    //get the container element where computer cards will be displayed
    const computerCardsContainer = document.getElementById('computerCards'); 
    //img for the face down cards to be displayed
    const faceDownCardImage = 'back-card.png';
    //array of 5 face down cards --> 
    const faceDownCards = Array(5).fill({ image: faceDownCardImage });
    //if a specific cardIndex is provided (not null), replace card with selectedComputerCard
  if (cardIndex != null) { faceDownCards[cardIndex] = selectedComputerCard; }
    displayCards(faceDownCards, computerCardsContainer);
  }
  //function to display cards in a container 
  function displayCards(cards, container) {
    container.innerHTML = ''; // clear cards currently in the game

    //cards styling --> https://developer.mozilla.org/en-US/docs/Web/API/Document/createElement
    cards.forEach(function (card) {
      const imgElement = document.createElement('img');
      //click event listener to each card's image element, calling the calculatePoints when click by user 
      imgElement.addEventListener("click", function() {
        calculatePoints(card);
      });
      //set the id of the image element to the card object itself 
      imgElement.id = card;
      //source (img file) for the card's img element
      imgElement.src = card.image;
      //styling for cards (width, height, margin)
      imgElement.style.width = '60px';
      imgElement.style.height = '80px';
      imgElement.style.margin = '10px';
      //adding the new html that creating to html element that's gonna have a card ** --> div contains 5 cards 
      container.appendChild(imgElement);
    });
  }
  //function to calculate points based on selected cards
  function calculatePoints(card) {
    //make button visible since it was made hidden in the beginning of the game 
    var button = document.getElementById('nextRoundButton');
    //false --> show it 
    button.hidden = false; 
    //set selectedPlayerCard to the card 
    selectedPlayerCard = card;
    // information for this taken from https://css-tricks.com/snippets/javascript/select-random-item-array/
    //math floor rounds number down https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Math/floor
    //math randon is used to return random integer https://www.w3schools.com/js/js_random.asp
    index = Math.floor(Math.random() * 5);
    selectedComputerCard =  computerCards[index];
    //calculate player points and computer points for round 
    playerPointsRound = calculatePlayerPoints(middleCard, selectedPlayerCard);
    computerPointsRound = calculatePlayerPoints(middleCard, selectedComputerCard);
    //display the result of the round
    var nextCardColorDisplay = document.getElementById('nextCardColorDisplay');
    //compare points to determine winner of round --> displayed at the end of each round
    //if player has more points than computer, then display player name + 'wins the round'
    if (playerPointsRound < computerPointsRound) { 
      nextCardColorDisplay.textContent = `${localStorage.getItem('playerName')} wins this round!`; 
      //to calculate the points if player wins the round, based on the cards played by computer, middle, and player
      playerPoints += getCardValue(middleCard) + getCardValue(selectedPlayerCard) + getCardValue(selectedComputerCard);
    }
    //or if computer has more points than player, then display that computer wins the round
    else if (playerPointsRound > computerPointsRound) {
      nextCardColorDisplay.textContent = `Computer wins this round!`; 
      //calculate the points that the computer would get if they win the round 
      computerPoints +=  getCardValue(middleCard) + getCardValue(selectedPlayerCard) + getCardValue(selectedComputerCard);
    }
    //if its a tie, usually if both players bust, then display that no one wins the round 
    else {
      nextCardColorDisplay.textContent = `No one wins this round!`; 
    }
    //update the displayed computer points 
    var computerPointsDisplay = document.getElementById('computerPoints');
    computerPointsDisplay.textContent = computerPoints + ""; 
    //update the displayed player points
    var playerPointsDisplay = document.getElementById('playerPoints');
    playerPointsDisplay.textContent = playerPoints + ""; 
    //display computer cards face down 
    displayComputerCards(index);
    //update middle card
    var playerPointsDisplay = document.getElementById('middleCard');
    playerPointsDisplay.src = middleCard.image; 

  }
  //calculate points earned by player 
  function calculatePlayerPoints(middleCard, gameCard) {

    var difference = getCardValue(middleCard) - getCardValue(gameCard);
    //16 is the maximum closeness score --> if both players have 17, they both bust and the round is cancelled,
    //if one player has 17, they automatically lose 
    if (difference < 0) return 17;
    //if not the same color return the difference + 4 points
    if (getColor(middleCard.suit) != getColor(gameCard.suit)) { return difference + 4; }
    //if the same color but different suit, return the difference plus 2 points
    if (middleCard.suit != gameCard.suit) { return difference + 2;}
    return difference;
  }
  //function to get color of a card - black or red --> for some reason in the code, using a if and else, the api does not want to distribute player cards
  // had to look for alternatives online came across ternary operator : https://betterprogramming.pub/5-alternatives-to-if-statements-for-conditional-branching-6e8e6e97430b
  // simplified, this function essentially says if the suit is either SPADES or CLUBS, then return black (using ?) else (using :) return red
  function getColor(suit) { return suit === 'CLUBS' || suit === 'SPADES' ? 'black' : 'red'; }

  //card values for game
  function getCardValue(card) {
    //get value from card object 
    const value = card.value;
    //determine numerical value of cards 
    if (value === 'ACE') { return 1; } 
    else if (value === 'JACK') { return 11; } 
    else if (value === 'QUEEN') { return 12; } 
    else if (value === 'KING') { return 13; }
    // return face value of numeric cards after converting to integer 
    else { return parseInt(value); }
  }
  //once game is over, be redirecting to the game over page (after 13 rounds)
  function gameOverPage() {
    //declare winner variable
    var winner;
    //determine the winner --> if the player has more points then they are the winner
    if (playerPoints > computerPoints) {
      winner = localStorage.getItem('playerName');
    // if the computer has more points then they are the winner
    } else if (playerPoints < computerPoints) {
      winner = 'Computer';
    //or a tie 
    } else {
      winner = 'It is a tie!';
    }

    //store player name, winner, and points in local storage for use in the game-over.html
    localStorage.setItem('playerName', localStorage.getItem('playerName'));
    localStorage.setItem('winner', winner);
    localStorage.setItem('playerPoints', playerPoints);
    localStorage.setItem('computerPoints', computerPoints);
    //redirect to game-over.html
    window.location.href = "game-over.html";
 }
  //function to restart game --> not indicated in the assignment instructions whether to restart the game the player 
  //needed to be brought back to the game page with the points just displayed at 0 with the same name 
  //or if i just needed to redirect them to the index page where they write their name and restart everything again 
  function restartGame() {
    window.location.href = 'index.html'
  }
